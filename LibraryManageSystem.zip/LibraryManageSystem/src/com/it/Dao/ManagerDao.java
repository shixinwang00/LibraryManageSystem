package com.it.Dao;

import com.it.domain.Manager;
import com.it.utils.DBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.SQLException;

/**
 * 检查管理员是否存在
 * @author wsx
 * @create 2020-03-28-23:12
 */
public class ManagerDao {
    public boolean checkManager(String user,String pass){
        Manager manager=null;
        try {
            QueryRunner queryRunner = new QueryRunner(DBUtils.getDataSource());
            String sql="select * from manager where username=? and password=?";
            manager = queryRunner.query(sql, new BeanHandler<Manager>(Manager.class), user, pass);
            if(manager!=null){
                return true;
            }else{
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
