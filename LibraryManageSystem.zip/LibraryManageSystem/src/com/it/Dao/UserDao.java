package com.it.Dao;

import com.it.domain.User;
import com.it.utils.DBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

/**
 * @author wsx
 * @create 2020-03-28-20:44
 */
public class UserDao {
    /**
     * 检查用户输入
     * @param username
     * @return
     */
    public String checkUser(String username) {
        User user = null;
        try {
            QueryRunner queryRunner = new QueryRunner(DBUtils.getDataSource());
            String sql = "select * from user where username=?";
            user = queryRunner.query(sql, new BeanHandler<User>(User.class), username);
            if (user != null) {
                return "true";
            } else {
                return "false";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "none";
    }

    /**
     * 检查账号密码
     * @param username
     * @param password
     * @return
     */
    public boolean checkUserPass(String username, String password) {
        User user = null;
        try {
            QueryRunner queryRunner = new QueryRunner(DBUtils.getDataSource());
            String sql = "select * from user where username=? and password=?";
            user = queryRunner.query(sql, new BeanHandler<User>(User.class), username, password);
            if (user != null) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
