package com.it.Service;

import com.it.Dao.UserDao;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author wsx
 * @create 2020-03-27-11:49
 */
@WebServlet("/checkLogin")
public class checkLogin extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) {
        UserDao userDao = new UserDao();
        String username = req.getParameter("user");
        String password = req.getParameter("password");
        boolean flag = userDao.checkUserPass(username, password);
        HttpSession session = req.getSession();

        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String time = sdf.format(date);

        if (flag == true) {
            try {
                session.setAttribute("user", username);
                session.setAttribute("usertime", time);
                req.getRequestDispatcher("reader_home.jsp").forward(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
//                resp.getWriter().write("false");
                resp.sendRedirect("Login.html");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
