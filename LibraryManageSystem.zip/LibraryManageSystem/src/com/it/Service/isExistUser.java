package com.it.Service;

import com.it.Dao.UserDao;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author wsx
 * @create 2020-03-27-9:27
 */
@WebServlet("/isExistUser")
public class isExistUser extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) {
        UserDao userDao = new UserDao();
        String username = req.getParameter("username");
        String result = userDao.checkUser(username);

        if (result == "true") {
            try {
                resp.getWriter().write("true");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                resp.getWriter().write("false");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
