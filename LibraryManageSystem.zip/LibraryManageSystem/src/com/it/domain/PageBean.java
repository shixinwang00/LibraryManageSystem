package com.it.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wsx
 * @create 2020-04-01-11:12
 */
@Setter @Getter
public class PageBean {
    private Integer currPage;//当前页
    private Integer totalPage;//总页数
    private Integer totalCount;//总记录数
    private List<Books> booksList=new ArrayList<>();//书信息

    @Override
    public String toString() {
        return "PageBean{" +
                "currPage=" + currPage +
                ", totalPage=" + totalPage +
                ", totalCount=" + totalCount +
                ", booksList=" + booksList +
                '}';
    }
}
