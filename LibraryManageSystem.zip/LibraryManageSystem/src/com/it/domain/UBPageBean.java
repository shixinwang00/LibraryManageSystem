package com.it.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wsx
 * @create 2020-04-15-16:37
 */
@Getter
@Setter
public class UBPageBean {
    private Integer currPage;//当前页
    private Integer totalPage;//总页数
    private Integer totalCount;//总记录数
    private List<Userbook> booksList = new ArrayList<>();//表中数据信息

    @Override
    public String toString() {
        return "UBPageBean{" +
                "currPage=" + currPage +
                ", totalPage=" + totalPage +
                ", totalCount=" + totalCount +
                ", booksList=" + booksList +
                '}';
    }

}
