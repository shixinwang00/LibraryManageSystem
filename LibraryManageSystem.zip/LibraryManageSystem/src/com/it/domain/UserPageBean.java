package com.it.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wsx
 * @create 2020-04-20-13:48
 */
@Setter @Getter
public class UserPageBean {
    private Integer currPage;//当前页
    private Integer totalPage;//总页数
    private Integer totalCount;//总记录数
    private List<User> usersList = new ArrayList<>();


}
