package com.it.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * @author wsx
 * @create 2020-04-15-14:10
 */
@Setter@Getter
public class Userbook {
    private Integer id;
    private Integer uid;
    private Integer bid;
    private String username;
    private String name;
    private String author;
    private String category;
    private String borrowtime;
    private String returntime;
    private String duration;
    private Integer flag;

    @Override
    public String toString() {
        return "Userbook{" +
                "id=" + id +
                ", uid=" + uid +
                ", bid=" + bid +
                ", username='" + username + '\'' +
                ", name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", category='" + category + '\'' +
                ", borrowtime='" + borrowtime + '\'' +
                ", returntime='" + returntime + '\'' +
                ", duration='" + duration + '\'' +
                ", flag=" + flag +
                '}';
    }
}
