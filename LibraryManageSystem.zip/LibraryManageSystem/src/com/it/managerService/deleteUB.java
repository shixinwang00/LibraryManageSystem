package com.it.managerService;

import com.it.Dao.UserbookDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @author wsx
 * @create 2020-04-21-20:44
 */
@WebServlet("/deleteUB")
public class deleteUB extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String id = req.getParameter("id");
        UserbookDao userbookDao = new UserbookDao();
        int update=0;
        try {
            update = userbookDao.deleteUB(Integer.valueOf(id));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        req.getRequestDispatcher("borrowInf").forward(req,resp);
    }
}
