package com.it.managerService;

import com.it.Dao.BooksDao;
import com.it.domain.Books;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.print.Book;
import java.io.IOException;
import java.sql.SQLException;

/**
 * 根据id查找书籍并回显到修改书籍页面
 *
 * @author wsx
 * @create 2020-04-07-14:50
 */
@WebServlet("/findBooks")
public class findBooks extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String id = req.getParameter("id");
        BooksDao booksDao = new BooksDao();
        Books books = null;
        try {
            books = booksDao.findBooks(Integer.valueOf(id));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        req.setAttribute("books",books);
        req.getRequestDispatcher("books_modify.jsp").forward(req,resp);
    }
}
