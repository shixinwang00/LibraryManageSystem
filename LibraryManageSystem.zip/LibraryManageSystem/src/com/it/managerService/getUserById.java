package com.it.managerService;

import com.it.Dao.BooksDao;
import com.it.domain.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @author wsx
 * @create 2020-04-20-15:10
 */
@WebServlet("/getUserById")
public class getUserById extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        System.out.println(666);
        String id = req.getParameter("id");
        BooksDao booksDao = new BooksDao();
        User user=null;
        try {
            user = booksDao.getUserById(Integer.valueOf(id));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        req.setAttribute("user",user);
        req.getRequestDispatcher("manager_modifyuser.jsp").forward(req,resp);
    }
}
