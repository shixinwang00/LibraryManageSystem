package com.it.managerService;

import com.it.Dao.BooksDao;
import com.it.domain.Books;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.Map;

/**
 * @author wsx
 * @create 2020-04-07-14:44
 */
@WebServlet("/modifyBooks")
public class modifyBooks extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        BooksDao booksDao = new BooksDao();
        Books books = new Books();
        Map<String, String[]> map = req.getParameterMap();
        try {
            BeanUtils.populate(books,map);//将信息存放到books对象中
        } catch (Exception e) {
            e.printStackTrace();
        }
        int update=0;
        try {
            update = booksDao.modifyBooks(books);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if(update!=0){
            resp.sendRedirect("pageServlet");
        }
    }
}
