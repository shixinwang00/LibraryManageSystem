//package com.it.test;
//
//import com.it.domain.PageBean;
//import org.json.JSONException;
//import org.json.JSONObject;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//
///**
// * @author wsx
// * @create 2020-04-01-18:29
// */
//@WebServlet("/pagesServlet")
//public class pagesServlet extends HttpServlet {
//    @Override
//    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        BooksServlet booksServlet = new BooksServlet();
//        PageBean pageBean = booksServlet.getPageInf(req, resp);
//        JSONObject jsonObject = new JSONObject();
//        try {
//            jsonObject.put("count",pageBean.getTotalCount());
//            jsonObject.put("page",pageBean.getTotalPage());
//            jsonObject.put("currpage",pageBean.getCurrPage());
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//        resp.getWriter().print(jsonObject);
//    }
//}
