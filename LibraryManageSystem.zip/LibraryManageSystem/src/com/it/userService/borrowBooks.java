package com.it.userService;

import com.it.Dao.UserbookDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * @author wsx
 * @create 2020-04-15-14:19
 */
@WebServlet("/borrowBooks")
public class borrowBooks extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();
        String duration = req.getParameter("duration");
        String username = (String) session.getAttribute("user");//获取当前用户的用户名
        UserbookDao userbookDao = new UserbookDao();
        Integer uid = null;
        try {
            uid = userbookDao.getIdByname(username);//根据用户名获取id
        } catch (SQLException e) {
            e.printStackTrace();
        }
        String bid = req.getParameter("bid");
        //根据书的id获取书的信息
        List<String> bookList = null;
        try {
            bookList = userbookDao.getBookInfo(Integer.valueOf(bid));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        int update=0;
        try {
            update = userbookDao.updateUB(uid, username, Integer.valueOf(bid), bookList,duration);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if(update!=0){
            session.setAttribute("meg","恭喜您，借阅成功！");
            req.getRequestDispatcher("borrowinf").forward(req,resp);
        }
    }
}
