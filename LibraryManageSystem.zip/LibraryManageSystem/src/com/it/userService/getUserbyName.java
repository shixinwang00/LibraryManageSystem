package com.it.userService;

import com.it.Dao.UserbookDao;
import com.it.domain.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @author wsx
 * @create 2020-04-15-18:18
 */
@WebServlet("/getUserbyName")
public class getUserbyName extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();
        String user = (String) session.getAttribute("user");
        System.out.println(user);
        UserbookDao userbookDao = new UserbookDao();
        User us = null;
        try {
            us = userbookDao.getUserByName(user);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(us);
        req.setAttribute("user",us);
        req.getRequestDispatcher("reader_modify.jsp").forward(req,resp);
    }
}
