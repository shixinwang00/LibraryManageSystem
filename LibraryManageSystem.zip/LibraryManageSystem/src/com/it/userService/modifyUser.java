package com.it.userService;

import com.it.Dao.UserbookDao;
import com.it.domain.User;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.Map;

/**
 * @author wsx
 * @create 2020-04-15-18:43
 */
@WebServlet("/modifyUser")
public class modifyUser extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        UserbookDao userbookDao = new UserbookDao();
        Map<String, String[]> parameterMap = req.getParameterMap();
        User user = new User();
        //将参数封装成对象
        try {
            BeanUtils.populate(user, parameterMap);
        } catch (Exception e) {
            e.printStackTrace();
        }
        int update = 0;
        try {
            update = userbookDao.modifyUser(user);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        req.setAttribute("msg", "信息修改成功！");
        req.getRequestDispatcher("reader_home.jsp").forward(req, resp);
    }
}
