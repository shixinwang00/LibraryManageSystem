package com.it.userService;

import com.it.Dao.BooksDao;
import com.it.domain.Books;
import com.it.domain.PageBean;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * @author wsx
 * @create 2020-04-13-15:49
 */
@WebServlet("/queryBooks")
public class queryBooks extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String query = req.getParameter("query");
        String currentPages = req.getParameter("currentPage");
        if (currentPages == null || "".equals(currentPages)) {
            currentPages = "1";
        }
        Integer currentPage = Integer.valueOf(currentPages);
        //防止点上一页时越界
        if (currentPage <= 1) {
            currentPage = 1;
        }
        PageBean pageBean = new PageBean();

        BooksDao booksDao = new BooksDao();
        Long totalCount = null;
        if(query == null || "".equals(query)){
            try {
                totalCount=booksDao.totalCount();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            try {
                totalCount=booksDao.queryCount(query);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        //总记录数
        pageBean.setTotalCount(totalCount.intValue());
        //每页的记录数
        Integer counts = 8;
        //总页数
        double totalPage = Math.ceil(1.0 * pageBean.getTotalCount() / counts);
        if (currentPage >= (int) totalPage) {
            currentPage = (int) totalPage;
        }
        //当前页
        pageBean.setCurrPage(Integer.valueOf(currentPage));
        pageBean.setTotalPage((int) totalPage);
        //分页list集合
        List<Books> pageList = null;
        if (query == null || "".equals(query)) {
            try {
                pageList = booksDao.getPageList(currentPage, counts);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            try {
                pageList=booksDao.queryPageList(currentPage,counts,query);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        pageBean.setBooksList(pageList);
        //System.out.println(pageBean);
        req.setAttribute("query",query);
        req.setAttribute("pageBean", pageBean);
        req.getRequestDispatcher("reader_query.jsp").forward(req, resp);
    }
}
