package com.it.Service;

import com.it.domain.User;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import com.it.Dao.UserDao;

/**
 * @author wsx
 * @create 2020-03-27-11:10
 */
@WebServlet("/isExistUserPass")
public class isExistUserPass extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) {
        UserDao userDao = new UserDao();
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        boolean flag = userDao.checkUserPass(username, password);
        if(flag==true){
            try {
                resp.getWriter().write("true");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            try {
                resp.getWriter().write("false");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
