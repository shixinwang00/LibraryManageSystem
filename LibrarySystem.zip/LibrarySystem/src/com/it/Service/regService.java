package com.it.Service;

import com.it.utils.DBUtils;
import org.apache.commons.dbutils.QueryRunner;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;

/**
 * @author wsx
 * @create 2020-03-27-8:34
 */
@WebServlet("/regService")
public class regService extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) {
        resp.setContentType("text/html;charset=UTF-8");
        try {
            req.setCharacterEncoding("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String username=req.getParameter("username");
        String password = req.getParameter("password");
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String phone = req.getParameter("phone");
        try{
            QueryRunner queryRunner = new QueryRunner(DBUtils.getDataSource());
            String sql="insert into user values(?,?,?,?,?,?)";
            int update = queryRunner.update(sql, null, username, password, name, email, phone);
            if(update!=0){
                req.getRequestDispatcher("Login.html").forward(req,resp);
            }else{
                req.getRequestDispatcher("Register.html").forward(req,resp);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
