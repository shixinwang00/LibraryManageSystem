package com.it.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * @author wsx
 * @create 2020-03-31-14:41
 */
@Setter @Getter
public class Books {
    private Integer id;
    private String number;
    private String name;
    private String author;
    private String press;
    private String date;
    private String category;
    private String information;
    private Integer num;

    @Override
    public String toString() {
        return "Books{" +
                "id=" + id +
                ", number='" + number + '\'' +
                ", name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", press='" + press + '\'' +
                ", date='" + date + '\'' +
                ", category='" + category + '\'' +
                ", information='" + information + '\'' +
                ", num=" + num +
                '}';
    }
}
