package com.it.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * @author wsx
 * @create 2020-03-28-23:11
 */
@Getter @Setter
public class Manager {
    private Integer id;
    private String username;
    private String password;
}
