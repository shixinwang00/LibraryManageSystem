package com.it.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * @author wsx
 * @create 2020-03-28-20:42
 */
@Setter @Getter
public class User {
    private Integer id;
    private String username;
    private String password;
    private String name;
    private String email;
    private String phone;

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }
}
