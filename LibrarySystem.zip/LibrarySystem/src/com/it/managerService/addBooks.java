package com.it.managerService;

import com.it.Dao.BooksDao;
import com.it.domain.Books;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.print.Book;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

/**
 * @author wsx
 * @create 2020-03-31-15:26
 */
@WebServlet("/addBooks")
public class addBooks extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) {
        try {
            req.setCharacterEncoding("UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        //获取所有的请求参数
        Map<String, String[]> map = req.getParameterMap();
        Books book= new Books();
        BooksDao booksDao = new BooksDao();
        //用beanutils封装对象 name值要与对象中的变量名一致
        try {
            BeanUtils.populate(book,map);
            //System.out.println(book.getAuthor());
            //System.out.println(book.getCategory());
            int update = booksDao.addBooks(book);
            if(update!=0){
                resp.sendRedirect("pageServlet");
                //req.getRequestDispatcher("pageServlet").forward(req,resp);
            }else{
                req.setAttribute("error","添加图书失败！");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
