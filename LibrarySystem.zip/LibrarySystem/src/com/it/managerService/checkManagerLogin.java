package com.it.managerService;

import com.it.Dao.ManagerDao;
import com.it.domain.Manager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author wsx
 * @create 2020-03-28-23:22
 */
@WebServlet("/checkManagerLogin")
public class checkManagerLogin extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) {
        HttpSession session = req.getSession();
        try {
            req.setCharacterEncoding("utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String user = req.getParameter("user");

        String password = req.getParameter("password");
        ManagerDao managerDao = new ManagerDao();
        boolean flag = managerDao.checkManager(user, password);
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String time = sdf.format(date);

        if(flag==true){
            try {
                session.setAttribute("user",user);//如果登录成功 将数据存储到user中
                session.setAttribute("time",time);
                req.getRequestDispatcher("books_home.jsp").forward(req,resp);
                //resp.sendRedirect("books_home.jsp");//重定向到管理页面
            } catch (IOException | ServletException e) {
                e.printStackTrace();
            }
        }else{
            try {
                resp.sendRedirect("/System/Login.html");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

