package com.it.managerService;

import com.it.Dao.BooksDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @author wsx
 * @create 2020-04-07-13:45
 */
@WebServlet("/deleteBooks")
public class deleteBooks extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");//获取图书的id
        BooksDao booksDao = new BooksDao();
        int update=0;
        try {
            update = booksDao.deleteBooks(Integer.valueOf(id));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if(update!=0){
            resp.sendRedirect("pageServlet");
        }
    }
}
