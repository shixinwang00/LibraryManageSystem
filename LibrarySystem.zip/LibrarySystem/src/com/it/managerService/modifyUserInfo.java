package com.it.managerService;

import com.it.Dao.BooksDao;
import com.it.domain.User;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.Map;

/**
 * @author wsx
 * @create 2020-04-20-15:09
 */
@WebServlet("/modifyUserInfo")
public class modifyUserInfo extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        Map<String, String[]> map = req.getParameterMap();
        BooksDao booksDao = new BooksDao();
        User user = new User();
        try {
            BeanUtils.populate(user,map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        int update=0;
        try {
            update = booksDao.modifyUserInfo(user);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        req.getRequestDispatcher("userInfo").forward(req,resp);
    }
}
