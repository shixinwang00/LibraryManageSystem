//package com.it.test;
//
//import com.it.Dao.BooksDao;
//import com.it.domain.Books;
//import com.it.domain.PageBean;
//import net.sf.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//import java.sql.SQLException;
//import java.util.List;
//
///**
// * @author wsx
// * @create 2020-04-01-9:19
// */
//@WebServlet("/BooksServlet")
//public class BooksServlet extends HttpServlet {
//    @Override
//    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.setContentType("text/html");
//        req.setCharacterEncoding("utf-8");
//        resp.setCharacterEncoding("UTF-8");
//        PageBean pageBean = getPageInf(req,resp);
//        JSONObject jsonObject = new JSONObject();
//        try {
//            jsonObject.put("count",pageBean.getTotalCount());
//            jsonObject.put("page",pageBean.getTotalPage());
//            jsonObject.put("currpage",pageBean.getCurrPage());
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//        List<Books> booksList = pageBean.getBooksList();
//        JSONArray listArray = JSONArray.fromObject(booksList);
//        resp.getWriter().write(listArray.toString());
//    }
//
//    /**
//     * 分页
//     * servlet自定义的方法需要放在service init get post方法中才能被调用
//     * @param req
//     * @param resp
//     * @return
//     * @throws ServletException
//     * @throws IOException
//     */
//    public PageBean getPageInf(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
//        try {
//            BooksDao booksDao = new BooksDao();
//            PageBean pageBean = new PageBean();
//            //获取当前页码
//            String currentPage = req.getParameter("currentPage");
//            //System.out.println(currentPage);
//            pageBean.setCurrPage(Integer.valueOf(currentPage));
//            //总记录数
//            Long totalCount = booksDao.totalCount();
//            pageBean.setTotalCount(totalCount.intValue());
//            //每页的数据
//            Integer counts=8;
//            //总页数
//            double pageCount = Math.ceil(1.0*pageBean.getTotalCount() / counts);
//            pageBean.setTotalPage((int)pageCount);
//            //查询数据角标开始位置
//            Integer index = (pageBean.getCurrPage()-1)*counts;
//            List<Books> list = booksDao.getPageData(index,counts, condition);
//            //System.out.println(list);
//            pageBean.setBooksList(list);
//            //将数据存放到域中
//            //req.setAttribute("PageBean",pageBean);
//            //转发
//            return pageBean;
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//}
