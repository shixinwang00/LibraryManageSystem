package com.it.test;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @author wsx
 * @create 2020-03-29-13:42
 */
@WebServlet("/testServlet")
public class testServlet extends HttpServlet {
    @Override

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter pw=resp.getWriter();


        String txtname1=req.getParameter("txtname1");
        String txtname2=req.getParameter("txtname2");
        String txtname3=req.getParameter("txtname3");
        String txtname4=req.getParameter("txtname4");
        String txtname5=req.getParameter("txtname5");
        String txtname6=req.getParameter("txtname6");
        String publisher=req.getParameter("publisher");
        String category=req.getParameter("category");
        String introduction=req.getParameter("introduction");



        pw.write("<html>\r\n" +
                "<head>\r\n" +
                "<meta charset=\"UTF-8\">\r\n" +
                "<title>Insert title here</title>\r\n" +
                "</head>\r\n" +
                "<body>\r\n" +
                "<table border=\"1\">\r\n" +
                "<tr>\r\n" +
                "<th>书籍信息</th>\r\n" +
                "</tr>\r\n" +
                "<tr>\r\n" +
                "<td>书号</td>\r\n" +
                "<td>"+txtname1+"</td>\r\n" +
                "</tr>\r\n" +
                "<tr>\r\n" +
                "<td>书名</td>\r\n" +
                "<td>"+txtname2+"</td>\r\n" +
                "</tr>\r\n" +
                "<tr>\r\n" +
                "<td>作者</td>\r\n" +
                "<td>"+txtname3+"</td>\r\n" +
                "</tr>\r\n" +
                "<tr>\r\n" +
                "<td>出版社</td>\r\n" +
                "<td>"+publisher+"</td>\r\n" +
                "</tr>\r\n" +
                "<tr>\r\n" +
                "<td>出版日期</td>\r\n" +
                "<td>"+txtname4+"</td>\r\n" +
                "</tr>\r\n" +
                "<tr>\r\n" +
                "<td>价格</td>\r\n" +
                "<td>"+txtname5+"</td>\r\n" +
                "</tr>\r\n" +
                "<tr>\r\n" +
                "<td>库存位置</td>\r\n" +
                "<td>"+txtname6+"</td>\r\n" +
                "</tr>\r\n" +
                "<tr>\r\n" +
                "<td>类别</td>\r\n" +
                "<td>"+category+"</td>\r\n" +
                "</tr>\r\n" +
                "<tr>\r\n" +
                "<td>内容简介</td>\r\n" +
                "<td>"+introduction+"</td>\r\n" +
                "</tr>\r\n" +
                "</table>\r\n" +
                "</body>\r\n" +
                "</html>");

    }
}
