package com.it.userService;

import com.it.Dao.UserbookDao;
import com.it.domain.PageBean;
import com.it.domain.UBPageBean;
import com.it.domain.Userbook;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * @author wsx
 * @create 2020-04-15-16:18
 */
@WebServlet("/borrowinf")
public class borrowinf extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();
        String user = (String) session.getAttribute("user");
        String currentPages = req.getParameter("currentPage");
        //System.out.println(currentPages);
        if (currentPages == null || "".equals(currentPages)) {
            currentPages = "1";
        }
        Integer currentPage = Integer.valueOf(currentPages);
        //防止点上一页时越界
        if (currentPage <= 1) {
            currentPage = 1;
        }
        UBPageBean ubPageBean = new UBPageBean();
        UserbookDao userbookDao = new UserbookDao();
        Long totalCount = null;
        try {
            totalCount = userbookDao.getATotalCount(user);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //总记录数
        ubPageBean.setTotalCount(totalCount.intValue());
        //每页的记录数
        Integer counts = 8;
        //总页数
        double totalPage = Math.ceil(1.0 * ubPageBean.getTotalCount() / counts);
        if (currentPage >= (int) totalPage) {
            currentPage = (int) totalPage;
        }
        ubPageBean.setCurrPage(currentPage);
        ubPageBean.setTotalPage((int) totalPage);
        List<Userbook> list = null;
        try {
            list = userbookDao.getAUBList(user, currentPage, counts);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //System.out.println(list);
        ubPageBean.setBooksList(list);
        req.setAttribute("ubPageBean", ubPageBean);
        req.getRequestDispatcher("reader_borrowinf.jsp").forward(req, resp);
    }
}
