package com.it.userService;

import com.it.Dao.UserbookDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @author wsx
 * @create 2020-04-15-17:57
 */
@WebServlet("/returnBooks")
public class returnBooks extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String id = req.getParameter("id");
        UserbookDao userbookDao = new UserbookDao();
        int update=0;
        try {
            update = userbookDao.updateReturnTime(Integer.valueOf(id));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if(update!=0){
            resp.sendRedirect("borrowhistory");
        }
    }
}
