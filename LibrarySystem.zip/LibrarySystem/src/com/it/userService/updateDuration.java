package com.it.userService;

import com.it.Dao.UserbookDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @author wsx
 * @create 2020-04-15-17:37
 */
@WebServlet("/updateDuration")
public class updateDuration extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String id = req.getParameter("id");
        String duration = req.getParameter("duration");
        System.out.println(id);
        System.out.println(duration);
        UserbookDao userbookDao = new UserbookDao();
        int update = 0;
        try {
            update = userbookDao.updateConBoTime(Integer.valueOf(id), duration);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (update != 0) {
            req.getRequestDispatcher("borrowinf").forward(req, resp);
            //resp.sendRedirect("borrowinf");
        }
    }
}
