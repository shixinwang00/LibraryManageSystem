INSERT INTO `manager` (`id`, `username`, `password`) VALUES (1, 'zhangsan', '1234');
