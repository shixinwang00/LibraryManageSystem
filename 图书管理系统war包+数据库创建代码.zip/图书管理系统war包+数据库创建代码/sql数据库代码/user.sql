INSERT INTO `user` (`id`, `username`, `password`, `name`, `email`, `phone`) VALUES (1, 'w123456789', '123456', '小白', '1@qq.com', '12345678910');
INSERT INTO `user` (`id`, `username`, `password`, `name`, `email`, `phone`) VALUES (3, 'zhangsan', '1234', '张三', '123456789@qq.com', '12345678910');
INSERT INTO `user` (`id`, `username`, `password`, `name`, `email`, `phone`) VALUES (4, 'zhangsan1234', '123456', '张三', '123@qq.com', '12345678910');
INSERT INTO `user` (`id`, `username`, `password`, `name`, `email`, `phone`) VALUES (7, 'lisi123456', '123456', '李四', '123456789@qq.com', '12345678910');
INSERT INTO `user` (`id`, `username`, `password`, `name`, `email`, `phone`) VALUES (8, '123', '123456789', '小明', '123452@qq.com', '78894564651');
INSERT INTO `user` (`id`, `username`, `password`, `name`, `email`, `phone`) VALUES (12, 'wangwu123', '123456789', '王五', '123456@qq.com', '12345678910');
INSERT INTO `user` (`id`, `username`, `password`, `name`, `email`, `phone`) VALUES (13, 'xiaoming132', '789456123', '小明', '123@qq.com', '15687812121');
